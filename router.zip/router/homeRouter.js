const express=require('express');
const { HomePage } = require('../app/controller/HomeController');
const Router=express.Router()


Router.get('/',HomePage)



module.exports=Router
