const express=require('express')
const ejs=require('ejs')

const app=express()

app.set('view engine','ejs');
app.set('views','views')

const HomeRouter=require('./router/homeRouter')
app.use(HomeRouter)

const Port=1245
app.listen(Port,()=>{
    console.log(`server is running port http://localhost:${Port}`);
})

